﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SBCHomework.Controllers;

namespace SBCHomework.Models
{
    public class FriendsViewModel
    {
        public int FriendId { get; set; }
        public string UserName { get; set; }
    }
}
